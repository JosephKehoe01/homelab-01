#!/usr/bin/env python3
    # Parses /var/log/auth.log* for failed SSH attempts and writes evidence/auth_failures.csv

    import re, gzip, csv
    from pathlib import Path

    LOG_DIR = Path("/var/log")
    OUT = Path("evidence/auth_failures.csv")
    OUT.parent.mkdir(parents=True, exist_ok=True)

    pat = re.compile(r'^(?P<ts>\w{3}\s+\d{1,2}\s[\d:]{8})\s+(?P<host>\S+)\s+(?P<proc>[\w\-\./\[\]]+):\s+(?P<msg>.*?)(?P<ip>(?:\d{1,3}\.){3}\d{1,3})?(?:\s|$)')

    def lines():
        for p in sorted(LOG_DIR.glob("auth.log*")):
            if p.suffix == ".gz":
                with gzip.open(p, "rt", errors="ignore") as f:
                    for line in f: yield line.rstrip("\n")
            else:
                with p.open("r", errors="ignore") as f:
                    for line in f: yield line.rstrip("\n")

    rows = []
    for ln in lines():
        if ("Failed password" in ln) or ("Invalid user" in ln) or ("authentication failure" in ln):
            m = pat.match(ln)
            if m:
                g = m.groupdict()
                rows.append({
                    "timestamp": g.get("ts",""),
                    "host": g.get("host",""),
                    "process": g.get("proc","").strip(),
                    "src_ip": g.get("ip",""),
                    "message": g.get("msg","").strip()
                })

    with OUT.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["timestamp","host","process","src_ip","message"])
        w.writeheader()
        w.writerows(rows)
    print(f"CSV written:", OUT)
